package com.example.mymovieapp.network.responses.movieCredits

import com.example.mymovieapp.network.responses.movieCredits.Cast
import com.example.mymovieapp.network.responses.movieCredits.Crew

data class MovieCreditsResponse(
    val cast: List<Cast>,
    val crew: List<Crew>,
    val id: Int
)