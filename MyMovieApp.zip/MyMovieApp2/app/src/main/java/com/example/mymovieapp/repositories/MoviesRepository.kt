package com.example.mymovieapp.repositories

import com.example.mymovieapp.network.responses.movieCredits.MovieCreditsResponse
import com.example.mymovieapp.network.responses.movieDetails.MovieDetailsResponse
import com.example.mymovieapp.network.responses.movies.MoviesResponse

interface MoviesRepository {

    suspend fun getPopularMovies() : MoviesResponse

    suspend fun getMovieDetails(movieId : Int) : MovieDetailsResponse

    suspend fun getMovieCredits(movieId: Int) : MovieCreditsResponse
}