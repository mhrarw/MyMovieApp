package com.example.mymovieapp.network.responses.movieDetails

data class ProductionCountry(
    val iso_3166_1: String,
    val name: String
)