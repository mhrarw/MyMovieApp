package com.example.mymovieapp.models

data class Movie(
    val movieBackground: String,
    val movieTitle: String,
    val movieId: Int
)